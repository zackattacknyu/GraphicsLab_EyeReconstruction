This folder consists of scripts that were used to test various methods
	mentioned in the final report.
Included here is the code that shows I implemented the various algorithms
	that did work well and the ones that did not work well
	for my purposes.